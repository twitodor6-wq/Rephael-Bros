# 06 — Art Direction ופרומפטים לרקעים

## עקרונות כלליים לעיצוב הרקעים
- **משחק פלטפורמה 2D עם מצלמת צד אופקית**, לא ציור פוסטר, לא מסך משחק תלת־ממדי.
- מחלקים לשכבות פאראלקס: `BG_FAR` (רקע רחוק מלא), `BG_MID` (אלמנטים אמצעיים, שקיפות לפי הצורך), `BG_NEAR` (שורשים וקורים קרובים ללא חסימת הגיבור), `BG_OVERLAY` (ערפל/חלקיקים עם alpha מאומת), וספרייטים קוליזיוניים עצמאיים.
- שורש שניתן להיאחז בו עם מטר חייב להיות **אובייקט משחק ייעודי ומסומן**, לא רק ענף שמצויר ברקע.
- כדאי לייצר קטעים אופקיים רחבים שניתן לשכפל/לחבר בקלות, ולהימנע מתפרים צורמים; אימות seamless נעשה בעריכת תמונה, לא בהבטחה של פרומפט בלבד.
- מומלץ WebP/PNG בהתאם לדרישות alpha; יש **לאמת בפועל** שהתמונה שקופה כשצריך, כי כיתוב 'transparent' בפרומפט אינו הבטחה לערוץ alpha.
- HUD, דמויות, פלטפורמות וגוף קרב הבוס אינם חלק מהציור של BG_FAR.

## יער הקורים — ביצתי, כבד ומאיים, ללא פנסים
פלטה: ירוק ביצה, חום טחוב, תכלת/טורקיז מרוסן, עץ רטוב, קורים לבנים־אפורים. פחות 'כפר חמוד', יותר טריטוריה של עכבישים, ביצות רדודות, ענפים לחים וקורים עבים. **אין פנסים מלאכותיים**. תאורה רק מערפל אור, השתקפויות טבעיות וביולומינסנציה עדינה.

### Prompt — BG_MID, תחילת יער הקורים
```text
Create a wide horizontal side-view MIDGROUND background layer for an original 2D side-scrolling fantasy platformer. Environment: spider-infested underground swamp forest with enormous twisted roots, damp tree trunks, shallow dark swamp pools, heavy hanging moss, huge silver spider webs stretched between roots, silk bridges, cocoon clusters and egg sacs. Painterly 2D game art, mysterious but not horror, readable central gameplay band, parallax-ready horizontal composition. No characters, no gameplay platforms, no text, no UI, no lanterns, no artificial lights, no cinematic three-quarter perspective. Muted swamp green, dark brown, pale web white, subdued teal and natural bioluminescence. Keep useful empty space for player action.
```

### Prompt — BG_FAR
```text
Wide distant background for a 2D side-scrolling fantasy platformer: a humid underground swamp forest, silhouettes of giant roots and trunks fading into turquoise-gray fog, barely visible giant webs and stagnant water reflections. Low contrast, large soft shapes, natural scattered glow only. Horizontal side-on perspective, parallax background, no foreground platforms, no lamps, no text.
```

### Prompt — BG_NEAR
```text
2D side-scrolling parallax NEAR-BACKGROUND elements: dark gnarled roots, hanging damp moss, close silk web curtains, dangling egg sacs, spider silk threads and silhouetted swamp reeds. These elements sit BEHIND gameplay; leave most of the action band unobstructed. Separate foreground shapes with empty/transparent regions where practical. Flat side-view, painterly original fantasy platform-game art, no lamps, no text.
```

### Prompt — BG_OVERLAY transparent
```text
Transparent PNG atmospheric VFX overlay for a 2D side-scrolling underground spider swamp: very sparse drifting fog, dew sparkles, spores, and a few thin floating web strands. Genuine alpha-channel transparency, no background scenery, no roots, no characters, no tree silhouettes, no lanterns, no text. Subtle enough to keep the playable area readable.
```

## מעבר/כלא
שילוב עץ חי, קליפות מחורצות, שרף וקשרים אורגניים שאינם נראים כמו כלא אבן סטנדרטי. יש לשמור על סימון ברור של דלת פעילה, מנוף, קטע שביר ונקודת מטר — כל אחד כאובייקט נפרד.

## מערת היענים
מבט צד על תקרת סלע ושורשים מחוררת, טלגרף ברור לניקור, אלמנטים קומיים של צווארים ארוכים, אבק שנושר ושבירת ביצים. הביצה בקצה השלב היא אובייקט בימוי/אנימציה, לא חלק מרקע סטטי.

## ערבת העשב הגבוה
שכבות אופקיות רחבות עם עשב ענק; `foreground_grass` יכול להסתיר חלקית שחקן רוכב אך אסור להסתיר סכנות בלי אינדיקציה. להבחין בין משטחים ורקע לבין עשב אינטראקטיבי.

## כפר הקפה
הפוגה צבעונית וחמה יותר, שורשים חיים, צמחי קפה ופטריות, מתחמי תרבות ללא העתקה של בנייה אנושית רגילה. ההחלטה אם תרבות זו 'מגדלת' את בתיה עדיין בגדר כיוון.

## עולם הייטים — קרח ואדים
קרח, שלג, מעיינות חמים, גייזרים ושורשים קפואים. צורות מזוהות במבט צד. תרבות אחת של ייטים לבני־אפור ופנים אדמדמות. אזורי בוץ־שלג ומעיינות חיים בניגוד לקרח חיוור.

### Prompt — Yeti Valley
```text
Wide original 2D side-scrolling fantasy platformer background, side-on horizontal view of a magical underground ice-and-steam valley: frozen roots, layered ice caves, mineral hot springs, steaming pools, geysers, frost-covered rock, distant snow-monkey-inspired yeti village around natural warm water. Painterly fantasy game environment. Clear central gameplay band and strong parallax depth, not a poster and not a 3D camera view. Pale ice blue, white-grey snow, warm steam haze, muted moss and red stone accents. No UI, no player characters, no text.
```

## עץ התמיד — פנים השורשים
חדרים ומעברים עצומים ברוחב משתנה, מנהרות אנכיות וחללים חלולים בתוך שורש/גזע, מוטיבים של עליה וירידה, נחשים כחלק מהמפה. יש ליצור שכבות **גם עבור מצלמה שנעה לגובה**, לא רק פנורמה אופקית.

### Prompt — Tree of Eternity
```text
Original 2D side-scrolling fantasy platformer background art of the INSIDE of an immense ancient living tree, colossal hollow root shafts, layered wooden tunnels, natural spiral corridors, side openings, deep shadowed vertical chambers, subtle spores and distant warm natural glow. Side-on cross-section gameplay composition, designed for both horizontal and vertical scrolling and parallax. Wide readable passages, visually distinct upper and lower areas, painterly fantasy, no characters, no HUD, no text, no fixed ladders painted as playable objects.
```
